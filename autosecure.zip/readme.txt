1. extract files and install NodeJS if not installed
2. run in cmd "npm install"
3. setup config.json
4. run in cmd "node autosecure.js"
5. do /token and enter ur bot token then /start