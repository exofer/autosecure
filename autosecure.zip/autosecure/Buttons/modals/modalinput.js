module.exports={
    name:"modalinput",
    callback:async(client,interaction)=>{
        let type = interaction.customId.split("|")[1]
    }
}